using UnityEngine;
using UnityEngine.Events;

public class SecondObjective : MonoBehaviour
{
    Main_Quest Main_Quest;
    Update_UI Update_UI;
    Items_Count Items_Count;

    int objectsToCollect;
    [SerializeField] int totalObjectsToCollect;
    [SerializeField] string objectiveText;
    [SerializeField] GameObject objectivePanelComplete;
    [SerializeField] AudioClip progressClip;
    [SerializeField] AudioClip objectiveComplete;
    [SerializeField] GameObject fadeGameobject;


    public UnityEvent ThingsToActivateOnEnable;
    public UnityEvent ThingsToDeActivateOnDisable;

    private void OnEnable()
    {
        ThingsToActivateOnEnable?.Invoke();
    }

    private void Start()
    {
        PlayerCollisionEvents.OnDiamondHit += PlayerCollisionEvents_OnPlayerCollideWithDiamond;
        Update_UI = FindFirstObjectByType<Update_UI>();
        Main_Quest = FindFirstObjectByType<Main_Quest>();
        Items_Count = FindFirstObjectByType<Items_Count>();

        Items_Count.UpdateLevelNumber("Level 2");
        Items_Count.UpdateLevelProgress(objectsToCollect, totalObjectsToCollect);
        Update_UI.ShowTextUpdate(objectiveText, 3f);
        Main_Quest.UpdateMainQuest(objectiveText, objectsToCollect, totalObjectsToCollect);
    }

    private void PlayerCollisionEvents_OnPlayerCollideWithDiamond()
    {
        if (objectsToCollect < totalObjectsToCollect)
        {
            objectsToCollect++;
            SFX_Manager.PlaySound(progressClip);
            Main_Quest.UpdateMainQuest(objectiveText, objectsToCollect, totalObjectsToCollect);
            Items_Count.UpdateLevelProgress(objectsToCollect, totalObjectsToCollect);

            if (objectsToCollect == totalObjectsToCollect)
            {
                SFX_Manager.PlaySound(objectiveComplete);
                /////////////////////////////////// 
                /// 
                ///       CAN CALL AD HERE
                /// 
                ///////////////////////////////////




                // OBJECTIVE COMPLETE

                PlayerPrefs.SetInt("L2", 1);
                Items_Count.UpdateLevelProgress(objectsToCollect, totalObjectsToCollect);
                Main_Quest.UpdateMainQuest(objectiveText, objectsToCollect, totalObjectsToCollect);
                Update_UI.ShowTextUpdate("Objective complete", 1f);
                ThingsToDeActivateOnDisable?.Invoke();
                gameObject.SetActive(false);
                fadeGameobject.SetActive(true);
                Invoke(nameof(EnableObjectivePanel), 0.9f);
            }
        }
    }

    void EnableObjectivePanel()
    {
        objectivePanelComplete.SetActive(true);
    }

}
