using UnityEngine;
using UnityEngine.Events;

public class ThirdObjective : MonoBehaviour
{
    Main_Quest Main_Quest;
    Update_UI Update_UI;
    Items_Count Items_Count;

    int ObjsThrown;
    [SerializeField] int totalObjThrownAtGranny;
    [SerializeField] string objectiveText;
    [SerializeField] GameObject objectivePanelComplete;
    [SerializeField] AudioClip progressClip;
    [SerializeField] AudioClip objectiveComplete;
    [SerializeField] GameObject fadeGameobject;

    public UnityEvent ThingsToActivateOnEnable;

    private void OnEnable()
    {
        ThingsToActivateOnEnable?.Invoke();
    }

    private void Start()
    {
        PickableObject.OnObjectHitGranny += PickableObject_OnObjectHitGranny;
        Update_UI = FindFirstObjectByType<Update_UI>();
        Main_Quest = FindFirstObjectByType<Main_Quest>();
        Items_Count = FindFirstObjectByType<Items_Count>();

        Items_Count.UpdateLevelNumber("Level 3");
        Items_Count.UpdateLevelProgress(ObjsThrown, totalObjThrownAtGranny);
        Update_UI.ShowTextUpdate(objectiveText, 3f);
        Main_Quest.UpdateMainQuest(objectiveText, ObjsThrown, totalObjThrownAtGranny);
    }

    private void PickableObject_OnObjectHitGranny()
    {
        if (ObjsThrown < totalObjThrownAtGranny)
        {
            ObjsThrown++;
            SFX_Manager.PlaySound(progressClip);
            Main_Quest.UpdateMainQuest(objectiveText, ObjsThrown, totalObjThrownAtGranny);
            Items_Count.UpdateLevelProgress(ObjsThrown, totalObjThrownAtGranny);

            if (ObjsThrown == totalObjThrownAtGranny)
            {

                SFX_Manager.PlaySound(objectiveComplete);
                /////////////////////////////////// 
                /// 
                ///       CAN CALL AD HERE
                /// 
                ///////////////////////////////////




                // OBJECTIVE COMPLETE

                PlayerPrefs.SetInt("L3", 1);
                Items_Count.UpdateLevelProgress(ObjsThrown, totalObjThrownAtGranny);
                Main_Quest.UpdateMainQuest(objectiveText, ObjsThrown, totalObjThrownAtGranny);
                Update_UI.ShowTextUpdate("Objective complete", 1f);
                gameObject.SetActive(false);
                fadeGameobject.SetActive(true);
                Invoke(nameof(EnableObjectivePanel), 0.9f);
            }
        }
    }

    void EnableObjectivePanel()
    {
        objectivePanelComplete.SetActive(true);
    }

}
