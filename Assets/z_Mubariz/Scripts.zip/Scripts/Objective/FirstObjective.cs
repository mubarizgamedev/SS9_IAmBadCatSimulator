using UnityEngine;

public class FirstObjective : MonoBehaviour
{
    Main_Quest Main_Quest;
    Update_UI Update_UI;
    Items_Count Items_Count;
    

    int hitToGranny;
    [SerializeField] int totalHitsToGranny;
    [SerializeField] string objectiveText;
    [SerializeField] GameObject objectiveCompletePanel;
    [SerializeField] AudioClip progressClip;
    [SerializeField] AudioClip objectiveComplete;
    [SerializeField] GameObject fadeGameobject;


    private void Start()
    {
        ChristmasGifts.OnGifthitGranny += ChristmasGifts_OnGifthitGranny;
        Update_UI = FindFirstObjectByType<Update_UI>();
        Main_Quest = FindFirstObjectByType<Main_Quest>();
        Items_Count = FindFirstObjectByType<Items_Count>();

        Items_Count.UpdateLevelNumber("Level 1");
        Items_Count.UpdateLevelProgress(hitToGranny, totalHitsToGranny);
        Update_UI.ShowTextUpdate(objectiveText, 3f);
        Main_Quest.UpdateMainQuest(objectiveText, hitToGranny, totalHitsToGranny);
    }

    private void ChristmasGifts_OnGifthitGranny()
    {
        if (hitToGranny < totalHitsToGranny)
        {

            hitToGranny++;
            SFX_Manager.PlaySound(progressClip);
            Items_Count.UpdateLevelProgress(hitToGranny, totalHitsToGranny);
            Main_Quest.UpdateMainQuest(objectiveText, hitToGranny, totalHitsToGranny);

            if (hitToGranny == totalHitsToGranny)
            {

                SFX_Manager.PlaySound(objectiveComplete);
                /////////////////////////////////// 
                /// 
                ///       CAN CALL AD HERE
                /// 
                ///////////////////////////////////




                // FIRST OBJECTIVE COMPLETE

                PlayerPrefs.SetInt("L1", 1);
                Items_Count.UpdateLevelProgress(hitToGranny, totalHitsToGranny);
                Main_Quest.UpdateMainQuest(objectiveText, hitToGranny, totalHitsToGranny);
                Update_UI.ShowTextUpdate("Objective complete", 1f);
                gameObject.SetActive(false);
                fadeGameobject.SetActive(true);
                Invoke(nameof(EnableObjectivePanel), 0.9f);
            }
        }
    }

    void EnableObjectivePanel()
    {
        objectiveCompletePanel.SetActive(true);
    }

   
}
