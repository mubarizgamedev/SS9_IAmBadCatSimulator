using UnityEngine;

public class Objective_Manager : MonoBehaviour
{
    [SerializeField] GameObject[] objectivesGameObjects;
    [SerializeField] EnemyHandler enemyHandler;
    private void Start()
    {
        NextObjective();
    }
    public void NextObjective()
    {

        //enemyHandler.ResetGrannyWandering();
        if (PlayerPrefs.GetInt("L1") != 1)
        {
            objectivesGameObjects[0].SetActive(true);
        }
        else if (PlayerPrefs.GetInt("L2") != 1)
        {
            objectivesGameObjects[1].SetActive(true);
        }
        else if (PlayerPrefs.GetInt("L3") != 1)
        {
            objectivesGameObjects[2].SetActive(true);
        }
        else if (PlayerPrefs.GetInt("L4") != 1)
        {
            objectivesGameObjects[3].SetActive(true);
        }
        else if (PlayerPrefs.GetInt("L5") != 1)
        {
            objectivesGameObjects[4].SetActive(true);
        }
    }
}
