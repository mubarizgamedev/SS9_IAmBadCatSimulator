using System.Collections;
using TMPro;
using UnityEngine;

public class Update_UI : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI updateText;
    [SerializeField] GameObject bgToHide;


    public void ShowTextUpdate(string text, float time)
    {
        StartCoroutine(ShowText(text, time));
    }

    IEnumerator ShowText(string text, float time)
    {
        bgToHide.SetActive(true);
        updateText.text = text;
        yield return new WaitForSeconds(time);
        bgToHide.SetActive(false);
    }
}
