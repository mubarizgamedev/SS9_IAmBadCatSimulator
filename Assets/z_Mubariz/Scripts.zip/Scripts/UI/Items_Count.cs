using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Items_Count : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI keyCountText;
    [SerializeField] TextMeshProUGUI speacialsCountText;
    [SerializeField] TextMeshProUGUI healthText;
    [SerializeField] TextMeshProUGUI levelNumberText;
    [SerializeField] Image levelProgress;


    int keyCount;
    int speacialCount;
    public void UpdateLevelNumber(string text)
    {
        levelNumberText.text = text;
    }

    public void IncrementKeyCount()
    {
        keyCount++;
        keyCountText.text = keyCount.ToString();
    }

    public void IncrementDiamondCount()
    {
        speacialCount++;
        speacialsCountText.text = speacialCount.ToString();
    }

   public void UpdateLevelProgress(int currrentValue, int totalValue)
    {
        float progress = (float)currrentValue / totalValue ;
        levelProgress.fillAmount = progress;
    }
}
