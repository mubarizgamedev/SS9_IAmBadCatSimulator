using System;
using UnityEngine;


public class PickableObject : MonoBehaviour
{

    bool canMove;
    float elapsedTime;
    bool canDamageGranny = true;
    float durationToReachPlayer = 0.2f;




    /////////////////////////////////// 
    /// 
    ///     LERPING POSITION
    /// 
    ///////////////////////////////////
    Vector3 startPosition;
    Transform target;

    [Tooltip("This text should be same as the text given in object picker script")]
    [SerializeField] string stringOfObject;
    [SerializeField] string GrannyTag;
    

    /////////////////////////////////// 
    /// 
    ///   EVENTS
    /// 
    ///////////////////////////////////

    public static event Action OnObjectReachedPlayer;
    public static event Action OnObjectHitGranny;


    #region UNITY FUNCTIONS  

    private void Start()
    {
        target = FindFirstObjectByType<ObjectTargetAtPlayer>().transform;
    }

    private void Update()
    {
        MoveObject();
    }


    #endregion


    #region HELPER FUNCTIONS

    void MoveObject()
    {
        if (canMove)
        {
            if (elapsedTime < durationToReachPlayer)
            {
                elapsedTime += Time.deltaTime;
                float t = elapsedTime / durationToReachPlayer; // Normalize to 0 - 1 range
                transform.position = Vector3.Lerp(startPosition, target.position, t);
            }
            else
            {
                transform.position = target.position; // Ensure exact final position
                canMove = false; // Stop movement only when finished
                OnObjectReachedPlayer?.Invoke();
            }
        }
    }

    public void MoveObject_TowardPlayer()
    {
        startPosition = transform.position;
        elapsedTime = 0f;
        canMove = true;
    }

    public string GetObjectName()
    {
        return stringOfObject;
    }
    #endregion


    private void OnCollisionEnter(Collision collision)
    {
        if (canDamageGranny)
        {
            if (collision.gameObject.CompareTag(GrannyTag))
            {
                OnObjectHitGranny?.Invoke();
                canDamageGranny = false;
            }
        }
    }
}

