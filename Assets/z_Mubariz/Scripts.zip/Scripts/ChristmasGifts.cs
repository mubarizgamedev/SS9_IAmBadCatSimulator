using System;
using UnityEngine;

public class ChristmasGifts : MonoBehaviour
{
    [SerializeField] string GrannyTag;
    public static event Action OnGifthitGranny;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag(GrannyTag))
        {
            Debug.Log("Gift hit granny");
            OnGifthitGranny?.Invoke();
        }
    }
}
