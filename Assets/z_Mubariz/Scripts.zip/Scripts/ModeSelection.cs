using UnityEngine;
using UnityEngine.SceneManagement;

public class ModeSelection : MonoBehaviour
{
    public void EnterGamePlayScene()
    {
        SceneManager.LoadScene("GamePlay");
    }
}
