using UnityEngine;

public class ThrowAbleObject : MonoBehaviour
{
    
}
