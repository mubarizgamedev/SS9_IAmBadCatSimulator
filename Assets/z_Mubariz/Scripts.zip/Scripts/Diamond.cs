using System;
using UnityEngine;

public class Diamond : MonoBehaviour
{

   
}
