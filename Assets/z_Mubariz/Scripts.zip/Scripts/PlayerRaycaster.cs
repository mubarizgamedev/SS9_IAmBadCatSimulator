using System;
using UnityEngine;
using UnityEngine.Events;

public class PlayerRaycaster : MonoBehaviour
{
    [Header("Testing")]
    public bool objectFound;
    public bool enemyFound;


    /////////////////////////////////// 
    /// 
    ///   RAYCASTING
    /// 
    ///////////////////////////////////

    [Header("RayCasting")]
    [SerializeField] float playerRayCastRange;
    [SerializeField] Transform rayCastOrigin;
    [SerializeField] LayerMask interactibleLayer;
    [SerializeField] LayerMask enemyLayer;




    /////////////////////////////////// 
    /// 
    ///     EVENTS
    /// 
    ///////////////////////////////////
    [Header("Events")]
    public UnityEvent OnInteractWithPickable;
    public UnityEvent OnInteractWithGranny;
    public UnityEvent NotInteractWithPickable;
    public UnityEvent NotInteractWithGranny;
    public static event Action OnObjectInWorldHide;



    /////////////////////////////////// 
    /// 
    ///     FIELDS
    /// 
    ///////////////////////////////////


    RaycastHit hit;
    public GameObject currentPickedObjet;
    public string currentObjectName;



    #region UNITY FUNCTIONS

    private void Start()
    {
      
            
        ObjectThrower.OnObjectThrown += ObjectThrower_OnObjectThrown;
        ObjectPicker.OnPickButtonClick += ObjectPicker_OnPickButtonClick;
        PickableObject.OnObjectReachedPlayer += PickableObject_OnObjectReachedPlayer;
    }

    private void ObjectThrower_OnObjectThrown()
    {
        currentObjectName = null;
        currentPickedObjet = null;
    }

    private void Update()
    {
        RayCasting_Object();
        RayCasting_Granny();
    }
    #endregion


    #region EVENT SUBSCRIBING
    private void PickableObject_OnObjectReachedPlayer()
    {
        HideInteractedGameObject();
    }

    private void ObjectPicker_OnPickButtonClick()
    {
        MoveObjectTowardPlayer();
    }
    #endregion


    #region HELPER FUNCTIONS

    void RayCasting_Object()
    {
        if (ObjectPicker.canGrabObject)   //IF THERE IS NOT ALREADY ANY OBJECT IN HAND
        {
            Ray ray = new Ray(rayCastOrigin.position, transform.forward);
            objectFound = Physics.Raycast(ray, out hit, playerRayCastRange, interactibleLayer);

            if (objectFound)
            {
                // OBJECT IN FRONT OF RAYCAST
                OnInteractWithPickable?.Invoke();
                if (hit.collider.gameObject.TryGetComponent<PickableObject>(out PickableObject pickableObject))
                {
                    currentObjectName = hit.transform.GetComponent<PickableObject>().GetObjectName();
                    currentPickedObjet = hit.transform.gameObject;
                }
                

            }
            else
            {
                NotInteractWithPickable?.Invoke();
            }
        }
    }
    void RayCasting_Granny()
    {
        Ray ray = new Ray(rayCastOrigin.position, transform.forward);
        enemyFound = Physics.Raycast(ray, out hit, playerRayCastRange, enemyLayer);

        if (enemyFound)
        {
            OnInteractWithGranny?.Invoke();
        }
        else
        {
            NotInteractWithGranny?.Invoke();
        }
    }

    public string InteractedObjectName()
    {
        return currentObjectName;
    }

     
    //CALL METHOD (Moveobject_Towardplayer) OF PICKABEL OBJECT CLASS
    void MoveObjectTowardPlayer()
    {
        if (objectFound && currentPickedObjet != null) // Ensure Raycast hit an object
        {
            if (currentPickedObjet.TryGetComponent(out PickableObject pickable))
            {
                pickable.MoveObject_TowardPlayer();
            }
        }
        else
        {
            Debug.LogWarning("No interactable object found in front of the player.");
        }
    }


    //HIDE OBJECT PRESENT IN WORLD AND SEND A CALL 
    void HideInteractedGameObject()
    {
        
        if (currentPickedObjet != null)
        {
            currentPickedObjet.SetActive(false);
        }
        else
        {
            Debug.LogWarning("No object found to hide.");
        }
        
        OnObjectInWorldHide?.Invoke();
    }
    #endregion
}
