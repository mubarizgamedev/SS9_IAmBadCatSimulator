using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class PausePanel : MonoBehaviour
{
    public UnityEvent OnPause;
    public UnityEvent OnResume;
    public UnityEvent OnReset;

    public void Home()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void Pause()
    {
        Time.timeScale = 0;
        OnPause?.Invoke();
    }
    public void Resume()
    {
        Time.timeScale = 1; 
        OnResume?.Invoke(); 
    }
    public void Reset()
    {
        Time.timeScale = 1;
        OnResume?.Invoke();
    }
}
