using UnityEngine;


public class SFX_Manager : MonoBehaviour
{ 
    public static void PlaySound(AudioClip clip)
    {
        GameObject soundGameObject = new GameObject("Sound");
        AudioSource audioSource = soundGameObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.Play();
        Destroy(soundGameObject, clip.length);
    }

    public static void PlayRandomSound(AudioClip[] clips)
    {
        if (clips == null || clips.Length == 0)
        {
            Debug.LogWarning("PlayRandomSound: No audio clips provided.");
            return;
        }

        // Pick a random clip from the array
        AudioClip randomClip = clips[Random.Range(0, clips.Length)];

        // Create an audio source
        GameObject soundGameObject = new GameObject("Sound");
        AudioSource audioSource = soundGameObject.AddComponent<AudioSource>();
        audioSource.clip = randomClip;
        audioSource.Play();

        // Destroy after the clip has finished playing
        Destroy(soundGameObject, randomClip.length);
    }

}
