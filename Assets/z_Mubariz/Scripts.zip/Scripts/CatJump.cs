using UnityEngine;

public class CatJump : MonoBehaviour
{
    [SerializeField] GameObject stillhands;
   public void DisableThisGameObject()
    {
        gameObject.SetActive(false);
        stillhands.SetActive(true);
    }
}
