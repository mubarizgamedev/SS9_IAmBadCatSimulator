using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations;
using UnityEngine.Events;

public class EnemyHandler : MonoBehaviour
{
    [Header("Preferences")]
    [SerializeField] float maxTimeGrannyChaseCat = 15f;
    [SerializeField] float stopDistanceBeforeCat = 1.5f;
    [SerializeField] float detectionRadius = 5f;
    [SerializeField] float maxHeadConstraintToCat = 1f;
    [SerializeField] float maxBodyConstraintToCat = 1f;
    [SerializeField] float missionFailAfterAttackCat = 2f;
    [SerializeField] AudioClip failSound;
    [SerializeField]
    AudioClip[] grannyAngerSounds;
   
    [Header("Components")]
    [SerializeField] GameObject WanderingChildGameObject;
    [SerializeField] Transform catTransform;
    [SerializeField] AimConstraint headAimConstraint;
    [SerializeField] RotationConstraint bodyRotationConstraint;
    [SerializeField] Animator cameraAnimator;

    [Header("Animation Parameter Strings")]
    [SerializeField] string animAttackBool = "isAttack";
    [SerializeField] string animAngerTrigger = "Anger";
    [SerializeField] string animReturnTrigger = "Return";
    [SerializeField] string cameraAnimShakeTrigger = "Shake";

    [Header("Events")]
    public UnityEvent OnGrannyHitCat;

    private Animator m_Animator;
    private NavMeshAgent m_Agent;
    private bool isChasingCat;
    private float chaseTimer;

    #region UNITY FUNCTIONS

    private void Start()
    {
        m_Animator = GetComponent<Animator>();
        m_Agent = GetComponent<NavMeshAgent>();

        PickableObject.OnObjectHitGranny += PickableObject_OnObjectHitGranny;
      
    }

    private void Update()
    {
        if (isChasingCat)
        {
            ChaseCat();
        }
    }

   
   
    #endregion

    #region HELPER FUNCTIONS

    private void PickableObject_OnObjectHitGranny()
    {
        SFX_Manager.PlayRandomSound(grannyAngerSounds);
        StartChasingCat();
    }

    private void StartChasingCat()
    {
        isChasingCat = true;
        chaseTimer = 0f;
        m_Animator.SetTrigger(animAngerTrigger);
        WanderingChildGameObject.SetActive(false);
    }

    private void ChaseCat()
    {
        if (!isChasingCat) return;

        m_Agent.SetDestination(catTransform.position);
        chaseTimer += Time.deltaTime;

        float distanceToCat = Vector3.Distance(transform.position, catTransform.position);

        if (distanceToCat <= stopDistanceBeforeCat)
        {
            AttackCat();
        }
        else if (chaseTimer >= maxTimeGrannyChaseCat)
        {
            ResetGrannyWandering();
        }
    }

    private void AttackCat()
    {
        isChasingCat = false;
        m_Agent.isStopped = true;

        bodyRotationConstraint.constraintActive = true;
        bodyRotationConstraint.weight = maxBodyConstraintToCat;
        headAimConstraint.weight = maxHeadConstraintToCat;

        m_Animator.SetBool(animAttackBool, true);

        if (IsCatInDetectionRadius())
        {
            Invoke(nameof(MissionFail), missionFailAfterAttackCat);
        }
    }

    private bool IsCatInDetectionRadius()
    {
        return Vector3.Distance(transform.position, catTransform.position) <= detectionRadius;
    }

    private void MissionFail()
    {
       
        OnGrannyHitCat?.Invoke();
    }

    public void ResetGrannyWandering()
    {
        isChasingCat = false;
        m_Agent.ResetPath();
        m_Agent.isStopped = false;

        bodyRotationConstraint.constraintActive = false;
        bodyRotationConstraint.weight = 0;
        headAimConstraint.weight = 0;

        m_Animator.SetBool(animAttackBool, false);
        WanderingChildGameObject.SetActive(true);
    }


   

    #endregion

    #region ANIMATION EVENTS

    public void ReturnToWalkingAnimation()
    {
        m_Animator.SetTrigger(animReturnTrigger);
    }

    public void CameraShake()
    {
        SFX_Manager.PlaySound(failSound);
        cameraAnimator.SetTrigger(cameraAnimShakeTrigger);
    }

    #endregion  
}
