using UnityEngine;
using UnityEngine.AI;

public class EnemyWandering : MonoBehaviour
{
    NavMeshAgent agent;
    public Transform[] wayPoints;
    int currentWayPointIndex;
    [SerializeField] float distBeforeWaypoint = 0.5f;


    #region UNITY FUNCTIONS

    private void Start()
    {
        Debug.Log("Entered granny wandering State");

        agent = GetComponentInParent<NavMeshAgent>();

        if (wayPoints.Length > 0)
        {
            MoveToNextWaypoint();
        }
    }

    public void Update()
    {
        if (!agent.pathPending && agent.remainingDistance <= distBeforeWaypoint)
        {
            MoveToNextWaypoint();
        }
    }


    #endregion


    #region HELPER FUNCTIONS

    void MoveToNextWaypoint()
    {
        if (wayPoints.Length == 0)
        {
            Debug.LogError("No waypoints assigned to the granny");
            return;
        }

        // Pick a random waypoint
        currentWayPointIndex = Random.Range(0, wayPoints.Length);
        agent.SetDestination(wayPoints[currentWayPointIndex].position);
    }
    #endregion
}
