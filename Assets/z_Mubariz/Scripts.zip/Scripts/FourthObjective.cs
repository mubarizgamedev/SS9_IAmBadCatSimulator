using UnityEngine;
using UnityEngine.Events;

public class FourthObjective : MonoBehaviour
{
    Main_Quest Main_Quest;
    Update_UI Update_UI;
    Items_Count Items_Count;

    int keysCount;
    [SerializeField] int toatlKeysToCollect;
    [SerializeField] string objectiveText;
    [SerializeField] GameObject objectivePanelComplete;
    [SerializeField] AudioClip progressClip;
    [SerializeField] AudioClip objectiveComplete;
    [SerializeField] GameObject fadeGameobject;

    public UnityEvent ThingsToActivateOnEnable;
    public UnityEvent ThingsToDeActivateOnDisEnable;

    private void OnEnable()
    {
        ThingsToActivateOnEnable?.Invoke();
    }

    private void Start()
    {
        PlayerCollisionEvents.OnKeyHit += PlayerCollisionEvents_OnPlayerCollideWithKey;
        Update_UI = FindFirstObjectByType<Update_UI>();
        Main_Quest = FindFirstObjectByType<Main_Quest>();
        Items_Count = FindFirstObjectByType<Items_Count>();

        Items_Count.UpdateLevelNumber("Level 4");
        Items_Count.UpdateLevelProgress(keysCount, toatlKeysToCollect);
        Update_UI.ShowTextUpdate(objectiveText, 3f);
        Main_Quest.UpdateMainQuest(objectiveText, keysCount, toatlKeysToCollect);
    }

    private void PlayerCollisionEvents_OnPlayerCollideWithKey()
    {
        if (keysCount < toatlKeysToCollect)
        {
            keysCount++;
            SFX_Manager.PlaySound(progressClip);
            Main_Quest.UpdateMainQuest(objectiveText, keysCount, toatlKeysToCollect);
            Items_Count.UpdateLevelProgress(keysCount, toatlKeysToCollect);

            if (keysCount == toatlKeysToCollect)
            {

                SFX_Manager.PlaySound(objectiveComplete);
                /////////////////////////////////// 
                /// 
                ///       CAN CALL AD HERE
                /// 
                ///////////////////////////////////




                // OBJECTIVE COMPLETE

                PlayerPrefs.SetInt("L4", 1);
                Items_Count.UpdateLevelProgress(keysCount, toatlKeysToCollect);
                Main_Quest.UpdateMainQuest(objectiveText, keysCount, toatlKeysToCollect);
                Update_UI.ShowTextUpdate("Objective complete", 1f);
                gameObject.SetActive(false);
                ThingsToDeActivateOnDisEnable?.Invoke();
                Invoke(nameof(EnableObjectivePanel), 0.9f);
            }
        }
    }

    void EnableObjectivePanel()
    {
        objectivePanelComplete.SetActive(true);
    }


}
