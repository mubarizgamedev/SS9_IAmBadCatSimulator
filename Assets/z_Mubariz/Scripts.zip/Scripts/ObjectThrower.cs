using System;
using UnityEngine;
using UnityEngine.Events;

public class ObjectThrower : MonoBehaviour
{
    GameObject objectToDisable;
    GameObject currentThrowableObject;

    [SerializeField] float throwForce = 10f;
    [SerializeField] Transform throwPosition;
    [SerializeField] AudioClip throwSound;

    /////////////////////////////////// 
    /// 
    ///    EVENTS
    /// 
    ///////////////////////////////////

    public UnityEvent OnObjectThrownEvent;
    public static event Action OnObjectThrown;


    [SerializeField]
    GameObject[] allThrowAbleObjects;


    #region HELPER FUNCTIONS

    public void Throwobject()
    {
        FindCurrentObject_String();
        if (currentThrowableObject != null)
        {
            GameObject cloneObject = Instantiate(currentThrowableObject,throwPosition.position, Quaternion.identity);


            // CHANGED LAYER TO 0
            //cloneObject.layer = 0;

            if (cloneObject != null)
            {
                Rigidbody rb = cloneObject.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.useGravity = true;
                    rb.isKinematic = false;
                    rb.AddForce(throwPosition.forward * throwForce, ForceMode.Impulse);
                    if (throwSound != null)
                    {
                        SFX_Manager.PlaySound(throwSound);
                    }
                        
                    currentThrowableObject = null;

                    if (objectToDisable != null)
                    {
                        objectToDisable.SetActive(false);
                    }

                    //OBJECT THROWN 

                    ObjectPicker.canGrabObject = true;

                    OnObjectThrownEvent?.Invoke();

                }
                else
                {
                    Debug.Log("rigidbody not found");
                }

            }
        }

       
    }


    void FindCurrentObject_String()
    {
        foreach (var gObj in allThrowAbleObjects)
        {
            if (gObj.activeSelf)
            {
                currentThrowableObject = gObj;

                objectToDisable = gObj;
                break;
            }
        }
    }

    #endregion
}
