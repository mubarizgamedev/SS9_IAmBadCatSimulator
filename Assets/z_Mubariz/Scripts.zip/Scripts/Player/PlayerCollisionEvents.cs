using UnityEngine;
using System;

public class PlayerCollisionEvents : MonoBehaviour
{
    Items_Count Items_Count;

    private void Start()
    {
        Items_Count = FindFirstObjectByType<Items_Count>();
    }

    [SerializeField] string DimaondTag = "Diamonds";
    [SerializeField] string KeyTag = "Key";

    public static event Action OnDiamondHit;
    public static event Action OnKeyHit;
    [SerializeField] AudioClip keySound;
    [SerializeField] AudioClip diamondSound;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(DimaondTag))
        {
            Debug.Log("Diamond hit");
            SFX_Manager.PlaySound(diamondSound);
            other.gameObject.SetActive(false);
            OnDiamondHit?.Invoke();
            Items_Count.IncrementDiamondCount();
        }
        if (other.CompareTag(KeyTag))
        {
            SFX_Manager.PlaySound(keySound);
            other.gameObject.SetActive(false);
            OnKeyHit?.Invoke();
            Items_Count.IncrementKeyCount();
        }
    }
}
