using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneHandler : MonoBehaviour
{
    [SerializeField] string sceneName;
    [SerializeField] float timeAfterEnable;
    private void OnEnable()
    {
        Invoke(nameof(Load_Scene), timeAfterEnable);
    }

    void Load_Scene()
    {
        SceneManager.LoadScene(sceneName);
    }
}
