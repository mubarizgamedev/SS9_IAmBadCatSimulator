using UnityEngine;

public class Breakable : MonoBehaviour
{
    [SerializeField] GameObject wholeGameobject;
    [SerializeField] GameObject breakGameobject;
    private void OnCollisionEnter(Collision collision)
    {
        wholeGameobject.SetActive(false);
        breakGameobject.SetActive(true);
        gameObject.layer = 0;
    }
}
